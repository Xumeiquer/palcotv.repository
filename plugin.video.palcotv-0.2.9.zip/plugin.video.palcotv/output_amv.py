import sys
import xbmcgui, xbmcplugin
 
addon_handle = int(sys.argv[1])
 
xbmcplugin.setContent(addon_handle, 'movies')
 
url = 'http://d3444.allmyvideos.net/d/6kmiqqv5yq5dh6lnnlhjvn6vgch6rnn7w7gntb4madii7xua2lptqk6gub3gg5a/video.mp4?v2'
li = xbmcgui.ListItem('The Amazing Spider Man 2 El poder de Electro 2014 BR LiNE XviD Mp3 LiNE 2 0 HQ Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4423.allmyvideos.net/d/z6mb45f5yq5dh6lnp3hjhmufej4wfkrts25v7uz3ndrh4cln2cud7tv23stn6uy/video.mp4?v2'
li = xbmcgui.ListItem('Dawn of the Planet of the Apes Cam Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d3442.allmyvideos.net/d/zcmfemf5yq5dh6lnh7hyz6olgmazpxtdycylqqnbzae3w4oj2nicfzjova/video.mp4?v2'
li = xbmcgui.ListItem('Crazy Stupid Love DVD Rip Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4423.allmyvideos.net/d/ysmae5v5yq5dh6lnwxhz32wpp5hqbp5qwmd3tlvr2us75ket76thju7rxb2wz4a/video.mp4?v2'
li = xbmcgui.ListItem('TYUBNM247 1080p WEB DL en castellano mkv', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4423.allmyvideos.net/d/6smgg4f5yq5dh6lnnhhjv4ouhl6rrx4irqvicjfhvwl4h22mvci3eslyzq/video.mp4?v2'
li = xbmcgui.ListItem('El Planeta de los Simios 2001 Bdrip m 1080p castellano c mkv', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4414.allmyvideos.net/d/62me26n5yq5dh6lna7hyd565fq3i44kdtxwbfysykell6nkfz7ikgjel4vhjf6a/video.mp4?v2'
li = xbmcgui.ListItem('El Gran Hotel Budapest 2014 camHQ Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4417.allmyvideos.net/d/6omlq6f5yq5dh6lncdhzbywrpungc42w3ndyxexkhwncv76vvzbhcay6veapx6a/video.mp4?v2'
li = xbmcgui.ListItem('Lobito Street 2013 HDrip XviD AC3 2 0 Castellano XKlusiveDD avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d3444.allmyvideos.net/d/6kmngs55yq5dh6lnnlhjvn6vgahreqmguqh5l6kgun6elkuoybefsze2ylcah5q/video.mp4?v2'
li = xbmcgui.ListItem('The Amazing Spider Man 2 El poder de Electro 2014 BR LiNE XviD Mp3 LiNE 2 0 HQ Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d3442.allmyvideos.net/d/zcmkms55yq5dh6lnh7hyz6olgnlwvr5u7h3szlbpxgkqzuito4vy43n6xm/video.mp4?v2'
li = xbmcgui.ListItem('Crazy Stupid Love DVD Rip Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4415.allmyvideos.net/d/2gmnus55yq5dh6lnvhgjx5mpgj4ejv2pllih4yrzdackqazywsosxpexp3w32vq/video.mp4?v2'
li = xbmcgui.ListItem('laprincesa y el sapo 320 Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4415.allmyvideos.net/d/ysmce6n5yq5dh6lnothm5mofho6g2zfojjob46u2wsph6pjsvwj4dt22ne/video.mp4?v2'
li = xbmcgui.ListItem('The Purge La Noche De Las Bestias HD CASTELLANO avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4415.allmyvideos.net/d/zomgssn5yq5dh6lnwxgi3noje4jw2kfnucbej2hguw6a7mrtljuejsxyf5vyipq/video.mp4?v2'
li = xbmcgui.ListItem('Hercules Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d3444.allmyvideos.net/d/6kmossf5yq5dh6lnnlhjvn6vgax64fbpt6hcetejy5meoigamkg6hs34n5ayn3q/video.mp4?v2'
li = xbmcgui.ListItem('The Amazing Spider Man 2 El poder de Electro 2014 BR LiNE XviD Mp3 LiNE 2 0 HQ Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4415.allmyvideos.net/d/ysmg6qn5yq5dh6lnothm5mofhoafotpxganstpzw7chndsdzclz6a23npu/video.mp4?v2'
li = xbmcgui.ListItem('The Purge La Noche De Las Bestias HD CASTELLANO avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4423.allmyvideos.net/d/ygmfssv5yq5dh6lnwpgm5n6qphwoxj2ofnmjes5b2hbabjzroh2hi4tsqliitii/video.mp4?v2'
li = xbmcgui.ListItem('V de Vendetta DVDRip Castellano mp4', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4755.allmyvideos.net/d/y2mccs55yq5dh6lnkdhm52gyeuxelexbfz6h3s643uve6o4ojrrwyllnvm/video.mp4?v2'
li = xbmcgui.ListItem('Aviones Equipo de rescate TSHQ Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d3442.allmyvideos.net/d/zcmp4sv5yq5dh6lnh7hyz6olgpptw5cvh3bepoon7x3md4zzetqeoh6foe/video.mp4?v2'
li = xbmcgui.ListItem('Crazy Stupid Love DVD Rip Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4417.allmyvideos.net/d/zcmdnxwryq5dh6lnkhhydywiem32zaxoihhrd45loga342zuaiocjeodxy22hty/video.mp4?v2'
li = xbmcgui.ListItem('Amor Sin Control Br Screener Castellano avi', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
url = 'http://d4415.allmyvideos.net/d/zkmn6555yq5dh6ln73gi3zwookft4u5dpo6qnrvk23zfnl7ndxcjxf7wze/video.mp4?v2'
li = xbmcgui.ListItem('Vikin 1x03 Castellano 720p mkv', iconImage='')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 
xbmcplugin.endOfDirectory(addon_handle)
